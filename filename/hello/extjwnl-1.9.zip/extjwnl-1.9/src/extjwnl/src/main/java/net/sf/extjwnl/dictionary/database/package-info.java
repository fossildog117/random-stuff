/**
 * Classes for accessing databases that contain dictionary information.
 *
 * @author John Didion (jdidion@didion.net)
 * @author <a href="http://autayeu.com/">Aliaksandr Autayeu</a>
 */
package net.sf.extjwnl.dictionary.database;