/**
 * Classes used by <code>FileBackedDictionary</code> to interface with the filesystem.
 *
 * @author John Didion (jdidion@didion.net)
 * @author <a href="http://autayeu.com/">Aliaksandr Autayeu</a>
 */
package net.sf.extjwnl.dictionary.file_manager;